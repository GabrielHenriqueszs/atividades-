package com.example.movie_database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
