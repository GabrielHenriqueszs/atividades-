package com.seuprojeto.minhaaplicacaoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaAplicacaoWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
